import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        // a. Crear e instanciar 15 objetos de tipo EstudianteTemporal y añadirlos a una lista
        List<EstudianteTemporal> estudiantesTemporales = new ArrayList<>();
        String[] nombresTemporales = {"Alice", "Bob", "Charlie", "David", "Eva", "Randy", "Grace", "Roberto", "Ivy", "Jack", "Kate", "Liam", "Mia", "Noah", "Olivia"};

        for (int i = 0; i < 15; i++) {
            Direccion direccion = new Direccion("ZIP123", "Calle Principal", "Centro", "Ciudad");
            EstudianteTemporal estudianteTemporal = new EstudianteTemporal(nombresTemporales[i], 20 + i, direccion);
            NumeroCelular celular = new NumeroCelular("123-456-789" + i);
            estudianteTemporal.agregarNumeroCelular(celular);
            estudiantesTemporales.add(estudianteTemporal);
        }

        // b. Crear e instanciar 15 objetos de tipo EstudianteUniversitario y añadirlos a una lista
        List<EstudianteUniversitario> estudiantesUniversitarios = new ArrayList<>();
        String[] nombresUniversitarios = {"John", "Michael", "Sarah", "William", "Emma", "James", "Sophia", "Daniel", "Oliver", "Ava", "Lucas", "Isabella", "Alexander", "Emily", "Benjamin"};

        for (int i = 0; i < 15; i++) {
            Direccion direccion = new Direccion("ZIP456", "Avenida Principal", "Centro", "Ciudad");
            EstudianteUniversitario estudianteUniversitario = new EstudianteUniversitario(nombresUniversitarios[i], "Smith", 18 + i, "Medicina", direccion);
            NumeroCelular celular = new NumeroCelular("987-654-321" + i);
            estudianteUniversitario.agregarNumeroCelular(celular);
            estudiantesUniversitarios.add(estudianteUniversitario);
        }

        // c. Convertir Lista<EstudianteTemporal> a Lista<EstudianteUniversitario>
        List<EstudianteUniversitario> estudiantesConvertidos = convertirEstudiantesTemporales(estudiantesTemporales);

        // d. Convertir Lista<EstudianteUniversitario> a String
        String listaDeEstudiantes = convertirListaAString(estudiantesConvertidos);

        // e. Convertir la lista de nombres a mayúsculas
        List<String> nombresEnMayusculas = convertirNombresAMayusculas(estudiantesConvertidos);

        // f. Ordenar la lista de nombres
        nombresEnMayusculas.sort(String::compareTo);

        // g. Filtrar la lista de nombres que empiezan con la letra “R” y ordenarla
        List<String> nombresFiltrados = filtrarNombresPorLetra(nombresEnMayusculas, 'R');
        nombresFiltrados.sort(String::compareTo);

        // Imprimir los resultados
        System.out.println("Lista de estudiantes universitarios: ");
        System.out.println(listaDeEstudiantes);

        System.out.println("\nNombres en mayúsculas: ");
        nombresEnMayusculas.forEach(System.out::println);

        System.out.println("\nNombres filtrados que empiezan con 'R': ");
        nombresFiltrados.forEach(System.out::println);

        // Ejecutar instrucciones adicionales

        // a. Dado un nombre, obtener el estudiante con nombre de coincidencia exacta.
        String nombreBuscado = "John";
        EstudianteUniversitario estudianteEncontrado = obtenerEstudiantePorNombre(estudiantesUniversitarios, nombreBuscado);

        if (estudianteEncontrado != null) {
            System.out.println("\nEstudiante encontrado por nombre: " + estudianteEncontrado.getNombre());
        } else {
            System.out.println("\nEstudiante no encontrado por nombre.");
        }

        // b. Dado una dirección, obtener el estudiante con dirección de coincidencia exacta.
        String direccionBuscada = "ZIP456";
        EstudianteUniversitario estudiantePorDireccion = obtenerEstudiantePorDireccion(estudiantesUniversitarios, direccionBuscada);

        if (estudiantePorDireccion != null) {
            System.out.println("\nEstudiante encontrado por dirección: " + estudiantePorDireccion.getNombre());
        } else {
            System.out.println("\nEstudiante no encontrado por dirección.");
        }

        // c. Dado un número celular, obtener todos los estudiantes con celulares de coincidencia exacta.
        String numeroCelularBuscado = "987-654-3211";
        List<EstudianteUniversitario> estudiantesPorCelular = obtenerEstudiantesPorNumeroCelular(estudiantesUniversitarios, numeroCelularBuscado);

        System.out.println("\nEstudiantes encontrados por número de celular:");
        estudiantesPorCelular.forEach(estudiante -> System.out.println(estudiante.getNombre()));

        // d. Dado dos números celulares, obtener todos los estudiantes que tengan los números de móvil XX-XXXXA y XX-XXXXB.
        String numeroCelularA = "987-654-3210";
        String numeroCelularB = "987-654-3211";
        List<EstudianteUniversitario> estudiantesPorCelulares = obtenerEstudiantesPorDosNumerosCelulares(estudiantesUniversitarios, numeroCelularA, numeroCelularB);

        System.out.println("\nEstudiantes encontrados por dos números de celular:");
        estudiantesPorCelulares.forEach(estudiante -> System.out.println(estudiante.getNombre()));
    }

    private static List<EstudianteUniversitario> obtenerEstudiantesPorNumeroCelular(List<EstudianteUniversitario> estudiantesUniversitarios, String numeroCelularBuscado) {
        return estudiantesUniversitarios.stream()
                .filter(estudiante -> estudiante.getCelulares().contains(numeroCelularBuscado))
                .collect(Collectors.toList());
    }

    private static List<EstudianteUniversitario> obtenerEstudiantesPorDosNumerosCelulares(List<EstudianteUniversitario> estudiantesUniversitarios, String numeroCelularA, String numeroCelularB) {
        return estudiantesUniversitarios.stream()
                .filter(estudiante -> estudiante.getCelulares().contains(numeroCelularA) && estudiante.getCelulares().contains(numeroCelularB))
                .collect(Collectors.toList());
    }

    private static EstudianteUniversitario obtenerEstudiantePorDireccion(List<EstudianteUniversitario> estudiantesUniversitarios, String direccionBuscada) {
        return estudiantesUniversitarios.stream()
                .filter(estudiante -> estudiante.getDireccion().getZip().equals(direccionBuscada))
                .findFirst()
                .orElse(null);
    }

    private static EstudianteUniversitario obtenerEstudiantePorNombre(List<EstudianteUniversitario> estudiantesUniversitarios, String nombreBuscado) {
        return estudiantesUniversitarios.stream()
                .filter(estudiante -> estudiante.getNombre().equals(nombreBuscado))
                .findFirst()
                .orElse(null);
    }

    private static List<String> filtrarNombresPorLetra(List<String> nombresEnMayusculas, char letra) {
        return nombresEnMayusculas.stream()
                .filter(nombre -> nombre.startsWith(String.valueOf(letra)))
                .collect(Collectors.toList());
    }

    public static List<EstudianteUniversitario> convertirEstudiantesTemporales(List<EstudianteTemporal> estudiantesTemporales) {
        List<EstudianteUniversitario> estudiantesUniversitarios = new ArrayList<>();
        for (EstudianteTemporal estudianteTemporal : estudiantesTemporales) {
            EstudianteUniversitario estudianteUniversitario = new EstudianteUniversitario(
                    estudianteTemporal.getNombre(),
                    "",
                    estudianteTemporal.getEdad(),
                    "",
                    estudianteTemporal.getDireccion()
            );
            estudianteUniversitario.getCelulares().addAll(estudianteTemporal.getCelulares());
            estudiantesUniversitarios.add(estudianteUniversitario);
        }
        return estudiantesUniversitarios;
    }

    public static String convertirListaAString(List<EstudianteUniversitario> estudiantesUniversitarios) {
        return estudiantesUniversitarios.stream()
                .map(estudiante -> estudiante.getNombre())
                .collect(Collectors.joining(", "));
    }

    public static List<String> convertirNombresAMayusculas(List<EstudianteUniversitario> estudiantesUniversitarios) {
        return estudiantesUniversitarios.stream()
                .map(estudiante -> estudiante.getNombre().toUpperCase())
                .collect(Collectors.toList());
    }
}
